by default pdfMake does not support exporting pdf in Persian language, here is a customized version which is working fine and exports pdf in Persian. I used Estedad font, you are free to change.
